-- 7. What is the total health care spending in the USA? 
SELECT SUM(HealthCareSpending.TotalSpending) as TotalSpending
FROM HealthCareSpending